import config from '../config.js';
import os from 'os';
import fs from 'fs';
import path from 'path';

export default {
    command: 'ping',
    aliases: ['pong', 'latency'],
    category: 'general',
    description: 'Check bot response time and connection status',
    usage: '.ping',
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const imagePath = path.join(process.cwd(), 'assets/thumb.png');
        
        try {
            // ========== QUOTES ARRAY ==========
            const quotes = [
                "Speed is key, and this bot delivers! 🚀",
                "Latency? What latency? ⚡",
                "Faster than lightning! 🌩️",
                "Pong! Your bot is alive and kicking! 💪",
                "Zero delay, pure speed! 🎯",
                "Like a cheetah on caffeine! 🐆",
                "Response time: Blazing fast! 🔥",
                "The Force is strong with this connection! 🌟",
                "Ready to serve at light speed! 💫",
                "Ping perfect! Bot operational! ✅"
            ];
            const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
            
            // ========== MEASURE LATENCY ==========
            const start = Date.now();
            await sock.sendMessage(chatId, { text: '🏓 *Calculating ping...*' }, { quoted: message });
            const end = Date.now();
            const latency = end - start;
            
            // ========== SYSTEM INFO FOR PING ==========
            const totalMemMB = (os.totalmem() / 1024 / 1024).toFixed(0);
            const freeMemMB = (os.freemem() / 1024 / 1024).toFixed(0);
            const usedMemMB = (totalMemMB - freeMemMB).toFixed(0);
            const memUsagePercent = ((usedMemMB / totalMemMB) * 100).toFixed(0);
            
            let uptime = Math.floor(process.uptime());
            const hours = Math.floor(uptime / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            
            // ========== DETERMINE STATUS ==========
            let statusEmoji = '🟢';
            let statusText = 'EXCELLENT';
            if (latency > 500) {
                statusEmoji = '🟡';
                statusText = 'SLOW';
            }
            if (latency > 1000) {
                statusEmoji = '🔴';
                statusText = 'POOR';
            }
            
            // ========== BUILD RESPONSE ==========
            let responseText = `╭━━━  ⟮  PONG! ⟯━━━━━━┈⊷\n`;
            responseText += `┃✵╭──────────────\n`;
            responseText += `┃✵│ ${statusEmoji} *STATUS:* ${statusText}\n`;
            responseText += `┃✵│ ⏱️ *LATENCY:* ${latency}ms\n`;
            responseText += `┃✵│ 💾 *RAM:* ${usedMemMB}/${totalMemMB} MB (${memUsagePercent}%)\n`;
            responseText += `┃✵│ ⏰ *UPTIME:* ${hours}h ${minutes}m\n`;
            responseText += `┃✵│ 🤖 *BOT:* ${config.botName || 'AMON-MD'}\n`;
            responseText += '┃✵╰──────────────\n';
            responseText += '╰━━━━━━━━━━━━━━━━━━┈⊷\n\n';
            
            responseText += '━━━━━━━━━━━━━━━━━━━━\n';
            responseText += '*┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃:*\n\n';
            
            responseText += ` ╭─────「 ✨ INSPIRATION 」───┈⊷ \n`;
            responseText += ` ││◦➛  ${randomQuote}\n`;
            responseText += ' ╰──────────────┈⊷ \n\n';
            
            responseText += `╭━━━  ⟮  SYSTEM ONLINE ⟯━━━━━━┈⊷\n`;
            responseText += `┃✵╭──────────────\n`;
            responseText += `┃✵│ 🚀 *Ready to serve you*\n`;
            responseText += `┃✵│ 💪 *Bot is alive and kicking*\n`;
            responseText += '┃✵╰──────────────\n';
            responseText += '╰━━━━━━━━━━━━━━━━━━┈⊷';
            
            // Send final response
            if (fs.existsSync(imagePath)) {
                await sock.sendMessage(chatId, {
                    image: { url: imagePath },
                    caption: responseText,
                    ...channelInfo
                }, { quoted: message });
            } else {
                await sock.sendMessage(chatId, { text: responseText, ...channelInfo }, { quoted: message });
            }
            
        } catch (error) {
            console.error('Ping error:', error);
            await sock.sendMessage(chatId, { 
                text: '🏓 Pong! Bot is alive but failed to get detailed stats.' 
            }, { quoted: message });
        }
    }
};