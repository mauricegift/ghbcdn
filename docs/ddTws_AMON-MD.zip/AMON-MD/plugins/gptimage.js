/**
 * GPT Image Command
 * Edit image using GPT Vision with prompt
 */

import axios from 'axios';
import FormData from 'form-data';
import path from 'path';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { webp2png } from '../lib/webp2mp4.js';
import sharp from 'sharp';
import config from '../config.js';

export default {
    name: 'gptimage',
    aliases: ['gptimg', 'editimage', 'aiimage', 'vision', 'gi'],
    category: 'ai',
    description: 'Edit image using GPT Vision with prompt',
    usage: '.gptimage <prompt> (reply to image/sticker)',
    
    async handler(sock, message, args, context) {
        try {
            const { chatId, sendReply, from } = context;
            const prefix = config.prefixes[0];
            
            // Check if message is a reply
            const ctxInfo = message.message?.extendedTextMessage?.contextInfo;
            if (!ctxInfo?.quotedMessage) {
                return await sendReply(sock, message,
                    '📷 *GPT Image Editor*\n\n' +
                    'Reply to an *image* or *sticker* with a prompt to edit it.\n\n' +
                    `Usage: ${prefix}gptimage <your prompt>\n\n` +
                    'Example: Reply to an image with:\n' +
                    `${prefix}gptimage change the background to a beach`
                );
            }
            
            // Get prompt from args
            const prompt = args.join(' ').trim();
            if (!prompt) {
                return await sendReply(sock, message,
                    '❌ Please provide a prompt!\n\n' +
                    `Usage: ${prefix}gptimage <your prompt>\n\n` +
                    'Example: change the background to a beach'
                );
            }
            
            const targetMessage = {
                key: {
                    remoteJid: from || chatId,
                    id: ctxInfo.stanzaId,
                    participant: ctxInfo.participant,
                },
                message: ctxInfo.quotedMessage,
            };
            
            // Check if quoted message is an image or sticker
            const quotedMsg = ctxInfo.quotedMessage;
            const isImage = !!quotedMsg.imageMessage;
            const isSticker = !!quotedMsg.stickerMessage;
            
            if (!isImage && !isSticker) {
                return await sendReply(sock, message, '❌ Please reply to an *image* or *sticker*!');
            }
            
            await sendReply(sock, message, '⏳ Processing image with GPT Vision...');
            
            // Download media
            const mediaBuffer = await downloadMediaMessage(
                targetMessage,
                'buffer',
                {},
                { logger: undefined, reuploadRequest: sock.updateMediaMessage },
            );
            
            if (!mediaBuffer) {
                return await sendReply(sock, message, '❌ Failed to download image. Please try again.');
            }
            
            // Convert sticker to image if needed
            let imageBuffer = mediaBuffer;
            if (isSticker) {
                const stickerMessage = quotedMsg.stickerMessage;
                const isAnimated = stickerMessage.isAnimated || stickerMessage.mimetype?.includes('animated');
                
                if (isAnimated) {
                    return await sendReply(sock, message, '❌ Animated stickers are not supported. Please use a static image or sticker.');
                }
                
                // Convert webp sticker to PNG
                try {
                    imageBuffer = await webp2png(mediaBuffer);
                } catch (error) {
                    console.error('[AMON-MD] Error converting sticker to PNG:', error);
                    return await sendReply(sock, message, '❌ Failed to convert sticker to image. Please try with a regular image.');
                }
            }
            
            // Convert to JPEG if needed (API might prefer JPEG)
            let finalImageBuffer = imageBuffer;
            try {
                const metadata = await sharp(imageBuffer).metadata();
                if (metadata.format !== 'jpeg' && metadata.format !== 'jpg') {
                    // Convert to JPEG
                    finalImageBuffer = await sharp(imageBuffer)
                        .jpeg({ quality: 90 })
                        .toBuffer();
                }
            } catch (error) {
                // If sharp fails, use original buffer
                console.error('[AMON-MD] Error processing image with sharp:', error);
                finalImageBuffer = imageBuffer;
            }
            
            // Prepare form data
            const form = new FormData();
            form.append('image', finalImageBuffer, {
                filename: 'image.jpg',
                contentType: 'image/jpeg'
            });
            form.append('param', prompt);
            
            // Send POST request to API
            const apiUrl = 'https://api.nexray.web.id/ai/gptimage';
            
            const response = await axios.post(apiUrl, form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                responseType: 'arraybuffer',
                timeout: 120000, // 2 minutes timeout for AI processing
                maxContentLength: 10 * 1024 * 1024, // 10MB max
            });
            
            if (!response.data) {
                return await sendReply(sock, message, '❌ No image received from API. Please try again.');
            }
            
            const resultImageBuffer = Buffer.from(response.data);
            
            // Validate buffer
            if (!resultImageBuffer || resultImageBuffer.length === 0) {
                return await sendReply(sock, message, '❌ Empty image received from API. Please try again.');
            }
            
            // Check file size (WhatsApp image limit is 5MB)
            const maxImageSize = 5 * 1024 * 1024; // 5MB
            if (resultImageBuffer.length > maxImageSize) {
                return await sendReply(sock, message,
                    `❌ Image too large: ${(resultImageBuffer.length / 1024 / 1024).toFixed(2)}MB (max 5MB)\n` +
                    'The API returned an image that exceeds WhatsApp limits.'
                );
            }
            
            // Send the modified image
            await sock.sendMessage(chatId, {
                image: resultImageBuffer,
                caption: `✨ *GPT Vision Result*\n\n📝 Prompt: ${prompt}\n\n✨ POWERED BY ${config.botName?.toUpperCase() || 'AMON-MD'}`
            }, { quoted: message });
            
        } catch (error) {
            console.error('[AMON-MD] Error in gptimage command:', error);
            const { sendReply } = context;
            
            if (error.response) {
                // API error
                const status = error.response.status;
                if (status === 400) {
                    return await sendReply(sock, message, '❌ Bad Request: Invalid parameters. Please check your prompt and image.');
                } else if (status === 429) {
                    return await sendReply(sock, message, '❌ Rate limit exceeded. Please try again later.');
                } else if (status === 500) {
                    return await sendReply(sock, message, '❌ Server error. Please try again later.');
                }
            }
            
            if (error.code === 'ECONNABORTED') {
                return await sendReply(sock, message, '❌ Request timeout. The image processing took too long. Please try again.');
            }
            
            return await sendReply(sock, message, `❌ Error: ${error.message || 'Unknown error occurred'}`);
        }
    },
};