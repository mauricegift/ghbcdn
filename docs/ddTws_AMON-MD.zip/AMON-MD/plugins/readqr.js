/**
 * Read QR Command - Read data from QR code image
 */

import axios from 'axios';
import config from '../config.js';

export default {
    name: 'readqr',
    aliases: ['qrread', 'scanqr', 'qrscanner', 'decodeqr'],
    category: 'general',
    description: 'Read data from a QR code image URL',
    usage: '.readqr <image_url>',
    
    async handler(sock, message, args, context) {
        try {
            const { sendReply } = context;
            const url = args[0];
            
            if (!url) {
                return sendReply(sock, message, `❌ Please provide an image URL.\n\n📌 Usage: ${config.prefixes[0]}readqr https://example.com/qr.png\n\n💡 You can also reply to an image with .readqr`);
            }
            
            await sendReply(sock, message, '⏳ Reading QR code...');
            
            const apiUrl = `https://api.giftedtech.co.ke/api/tools/readqr?apikey=gifted&url=${encodeURIComponent(url)}`;
            const response = await axios.get(apiUrl);
            
            if (!response.data.success) {
                return sendReply(sock, message, '❌ Failed to read QR code. Make sure the image contains a valid QR code.');
            }
            
            const qrData = response.data.result.qrcode_data;
            
            const responseText = `📷 QR CODE SCANNER\n\n🔍 *Data:* ${qrData}\n\n✨ POWERED BY ${config.botName?.toUpperCase() || 'AMON-MD'}`;
            
            await sendReply(sock, message, responseText);
            
        } catch (error) {
            console.error('[AMON-MD] Read QR error:', error);
            const { sendReply } = context;
            sendReply(sock, message, '❌ Error reading QR code. Please check the URL and try again.');
        }
    }
};