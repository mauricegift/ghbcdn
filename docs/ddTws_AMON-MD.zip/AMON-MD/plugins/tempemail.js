/**
 * Temp Mail Command - Generate temporary email
 */

import axios from 'axios';
import config from '../config.js';

export default {
    name: 'tempmail',
    aliases: ['tempmailgen', 'fakeemail', 'genemail'],
    category: 'general',
    description: 'Generate temporary email address',
    usage: '.tempmail',
    
    async handler(sock, message, args, context) {
        try {
            const { sendReply } = context;
            
            await sendReply(sock, message, '⏳ Generating temporary email...');
            
            const apiUrl = `https://api.giftedtech.co.ke/api/tempgen/v2/generate?apikey=gifted&mode=random`;
            const response = await axios.get(apiUrl);
            
            if (!response.data.success) {
                return sendReply(sock, message, '❌ Failed to generate temporary email.');
            }
            
            const email = response.data.result.email;
            
            const responseText = `📧 TEMPORARY EMAIL\n\n📨 *Email:* ${email}\n\n💡 Use .inbox to check messages\n\n✨ POWERED BY ${config.botName?.toUpperCase() || 'AMON-MD'}`;
            
            await sendReply(sock, message, responseText);
            
        } catch (error) {
            console.error('[AMON-MD] Temp mail error:', error);
            const { sendReply } = context;
            sendReply(sock, message, '❌ Error generating temporary email. Please try again later.');
        }
    }
};