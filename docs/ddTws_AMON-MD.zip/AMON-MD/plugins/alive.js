import config from '../config.js';
import os from 'os';
import fs from 'fs';
import path from 'path';

export default {
    command: 'alive',
    aliases: ['status', 'bot', 'health'],
    category: 'general',
    description: 'Check bot status and system information',
    usage: '.alive',
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const imagePath = path.join(process.cwd(), 'assets/thumb.png');
        
        try {
            // ========== QUOTES ARRAY ==========
            const quotes = [
                "Dream big, work hard.",
                "Stay humble, hustle hard.",
                "Believe in yourself.",
                "Success is earned, not given.",
                "Actions speak louder than words.",
                "The best is yet to come.",
                "Keep pushing forward.",
                "Do more than just exist.",
                "Progress, not perfection.",
                "Stay positive, work hard.",
                "Be the change you seek.",
                "Never stop learning.",
                "Chase your dreams.",
                "Be your own hero.",
                "Life is what you make of it.",
                "Do it with passion or not at all.",
                "You are stronger than you think.",
                "Create your own path.",
                "Make today count.",
                "Embrace the journey.",
                "The best way out is always through.",
                "Strive for progress, not perfection.",
                "Don't wish for it, work for it.",
                "Live, laugh, love.",
                "Keep going, you're getting there.",
                "Don’t stop until you’re proud.",
                "Success is a journey, not a destination.",
                "Take the risk or lose the chance.",
                "It’s never too late.",
                "Believe you can and you're halfway there.",
                "Small steps lead to big changes.",
                "Happiness depends on ourselves.",
                "Take chances, make mistakes.",
                "Be a voice, not an echo.",
                "The sky is the limit.",
                "You miss 100% of the shots you don’t take.",
                "Start where you are, use what you have.",
                "The future belongs to those who believe.",
                "Don’t count the days, make the days count.",
                "Success is not the key to happiness. Happiness is the key to success."
            ];
            const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
            
            // ========== UPTIME CALCULATION ==========
            let uptime = Math.floor(process.uptime());
            const days = Math.floor(uptime / 86400);
            uptime %= 86400;
            const hours = Math.floor(uptime / 3600);
            uptime %= 3600;
            const minutes = Math.floor(uptime / 60);
            const seconds = Number(uptime) % 60;
            
            const uptimeParts = [];
            if (days) uptimeParts.push(`${days}d`);
            if (hours) uptimeParts.push(`${hours}h`);
            if (minutes) uptimeParts.push(`${minutes}m`);
            if (seconds || uptimeParts.length === 0) uptimeParts.push(`${seconds}s`);
            const uptimeText = uptimeParts.join(' ');
            
            // ========== MEMORY INFORMATION ==========
            const totalMemMB = (os.totalmem() / 1024 / 1024).toFixed(0);
            const freeMemMB = (os.freemem() / 1024 / 1024).toFixed(0);
            const usedMemMB = (totalMemMB - freeMemMB).toFixed(0);
            const memUsagePercent = ((usedMemMB / totalMemMB) * 100).toFixed(0);
            
            // ========== CPU INFORMATION ==========
            const cpus = os.cpus();
            const cpuCores = cpus.length;
            const cpuModel = cpus[0]?.model.split('@')[0].trim() || 'Unknown';
            const loadAvg = os.loadavg();
            const load1m = loadAvg[0].toFixed(1);
            const load5m = loadAvg[1].toFixed(1);
            const load15m = loadAvg[2].toFixed(1);
            
            // ========== SYSTEM INFORMATION ==========
            const platform = os.platform();
            const platformMap = {
                'win32': 'Windows',
                'linux': 'Linux',
                'darwin': 'macOS',
                'android': 'Android'
            };
            const platformName = platformMap[platform] || platform;
            const arch = os.arch();
            const nodeVersion = process.version;
            
            // ========== TIME (Africa/Nairobi) ==========
            const getCurrentTime = () => {
                return new Date().toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: false,
                    timeZone: 'Africa/Nairobi'
                });
            };
            
            const getCurrentDate = () => {
                return new Date().toLocaleDateString('en-US', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                    timeZone: 'Africa/Nairobi'
                });
            };
            
            // ========== STATUS DETECTION ==========
            let statusEmoji = '🟢';
            let statusText = 'PERFECT';
            if (memUsagePercent > 80 || load1m > cpuCores) {
                statusEmoji = '🟡';
                statusText = 'MODERATE';
            }
            if (memUsagePercent > 90) {
                statusEmoji = '🔴';
                statusText = 'HEAVY';
            }
            
            // ========== BUILD RESPONSE ==========
            let responseText = `╭━━━  ⟮  ${config.botName || 'AMON-MD'} ⟯━━━━━━┈⊷\n`;
            responseText += `┃✵╭──────────────\n`;
            responseText += `┃✵│ ${statusEmoji} *STATUS:* ${statusText}\n`;
            responseText += `┃✵│ 🕐 *TIME:* ${getCurrentTime()}\n`;
            responseText += `┃✵│ 📅 *DATE:* ${getCurrentDate()}\n`;
            responseText += `┃✵│ ⏱️ *UPTIME:* ${uptimeText}\n`;
            responseText += `┃✵│ 💾 *RAM:* ${usedMemMB} MB / ${totalMemMB} MB (${memUsagePercent}%)\n`;
            responseText += `┃✵│ 🖥️ *OS:* ${platformName} (${arch})\n`;
            responseText += `┃✵│ 📦 *NODE:* ${nodeVersion}\n`;
            responseText += `┃✵│ ⚙️ *CPU:* ${cpuCores} Cores\n`;
            responseText += `┃✵│ 💻 *MODEL:* ${cpuModel.substring(0, 25)}${cpuModel.length > 25 ? '...' : ''}\n`;
            responseText += `┃✵│ 📊 *LOAD:* ${load1m} (1m) | ${load5m} (5m) | ${load15m} (15m)\n`;
            responseText += '┃✵╰──────────────\n';
            responseText += '╰━━━━━━━━━━━━━━━━━━┈⊷\n\n';
            
            responseText += '━━━━━━━━━━━━━━━━━━━━\n';
            responseText += '*┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃:*\n\n';
            
            // Performance analysis
            let performanceNote = '';
            let performanceEmoji = '✅';
            if (memUsagePercent < 50 && load1m < cpuCores * 0.7) {
                performanceNote = 'System running optimally';
                performanceEmoji = '✅';
            } else if (memUsagePercent < 75 && load1m < cpuCores) {
                performanceNote = 'Moderate load - OK';
                performanceEmoji = '⚠️';
            } else {
                performanceNote = 'High load - Consider restart';
                performanceEmoji = '🔴';
            }
            
            responseText += ` ╭─────「 📊 PERFORMANCE 」───┈⊷ \n`;
            responseText += ` ││◦➛  ${performanceEmoji} *Health:* ${performanceNote}\n`;
            responseText += ` ││◦➛  🎯 *Efficiency:* ${100 - memUsagePercent > 20 ? 'Good' : 'Needs Attention'}\n`;
            responseText += ` ││◦➛  🔄 *Recommendation:* ${memUsagePercent > 80 ? 'Restart recommended' : 'All good'}\n`;
            responseText += ' ╰──────────────┈⊷ \n\n';
            
            responseText += '━━━━━━━━━━━━━━━━━━━━\n';
            responseText += '*┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃:*\n\n';
            
            responseText += ` ╭─────「 ✨ INSPIRATION 」───┈⊷ \n`;
            responseText += ` ││◦➛  "${randomQuote}"\n`;
            responseText += ' ╰──────────────┈⊷ \n\n';
            
            responseText += `╭━━━  ⟮  SYSTEM ONLINE ⟯━━━━━━┈⊷\n`;
            responseText += `┃✵╭──────────────\n`;
            responseText += `┃✵│ 🟢 *Bot is alive and kicking!*\n`;
            responseText += `┃✵│ 💪 *Ready to serve you*\n`;
            responseText += `┃✵│ 🌟 *Type ${config.prefixes?.[0] || '.'}help for assistance*\n`;
            responseText += '┃✵╰──────────────\n';
            responseText += '╰━━━━━━━━━━━━━━━━━━┈⊷';
            
            // Send response
            if (fs.existsSync(imagePath)) {
                await sock.sendMessage(chatId, {
                    image: { url: imagePath },
                    caption: responseText,
                    ...channelInfo
                }, { quoted: message });
            } else {
                await sock.sendMessage(chatId, { text: responseText, ...channelInfo }, { quoted: message });
            }
            
        } catch (error) {
            console.error('Alive command error:', error);
            await sock.sendMessage(chatId, { 
                text: '✅ Bot is alive and running!' 
            }, { quoted: message });
        }
    }
};