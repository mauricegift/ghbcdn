import config from '../config.js';
/*****************************************************************************
 *                                                                           *
 *                     Developed By Qasim Ali                                *
 *                                                                           *
 *  🌐  GitHub   : https://github.com/GlobalTechInfo                         *
 *  ▶️  YouTube  : https://youtube.com/@GlobalTechInfo                       *
 *  💬  WhatsApp : https://whatsapp.com/channel/0029VagJIAr3bbVBCpEkAM07     *
 *                                                                           *
 *    © 2026 GlobalTechInfo. All rights reserved.                            *
 *                                                                           *
 *    Description: This file is part of the MEGA-MD Project.                 *
 *                 Unauthorized copying or distribution is prohibited.       *
 *                                                                           *
 *****************************************************************************/
import commandHandler from '../lib/commandHandler.js';
import path from 'path';
import fs from 'fs';

// ========== HELPER FUNCTIONS (No luxon) ==========
function getGreeting() {
    const now = new Date();
    const nairobiTime = new Date(now.toLocaleString('en-US', { timeZone: 'Africa/Nairobi' }));
    const currentHour = nairobiTime.getHours();
    if (currentHour >= 5 && currentHour < 12) return '🌅 Good morning';
    if (currentHour >= 12 && currentHour < 17) return '☀️ Good afternoon';
    if (currentHour >= 17 && currentHour < 20) return '🌆 Good evening';
    return '🌙 Good night';
}

function getCurrentTime() {
    const now = new Date();
    return now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
        timeZone: 'Africa/Nairobi'
    });
}

function getCurrentDate() {
    const now = new Date();
    return now.toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        timeZone: 'Africa/Nairobi'
    });
}

function getRandomQuote() {
    const quotes = [
        "Dream big, work hard.",
        "Stay humble, hustle hard.",
        "Believe in yourself.",
        "Success is earned, not given.",
        "Actions speak louder than words.",
        "The best is yet to come.",
        "Keep pushing forward.",
        "Do more than just exist.",
        "Progress, not perfection.",
        "Stay positive, work hard.",
        "Be the change you seek.",
        "Never stop learning.",
        "Chase your dreams.",
        "Be your own hero.",
        "Life is what you make of it.",
        "Do it with passion or not at all.",
        "You are stronger than you think.",
        "Create your own path.",
        "Make today count.",
        "Embrace the journey.",
        "The best way out is always through.",
        "Strive for progress, not perfection.",
        "Don't wish for it, work for it.",
        "Live, laugh, love.",
        "Keep going, you're getting there.",
        "Don’t stop until you’re proud.",
        "Success is a journey, not a destination.",
        "Take the risk or lose the chance.",
        "It’s never too late.",
        "Believe you can and you're halfway there.",
        "Small steps lead to big changes.",
        "Happiness depends on ourselves.",
        "Take chances, make mistakes.",
        "Be a voice, not an echo.",
        "The sky is the limit.",
        "You miss 100% of the shots you don’t take.",
        "Start where you are, use what you have.",
        "The future belongs to those who believe.",
        "Don’t count the days, make the days count.",
        "Success is not the key to happiness. Happiness is the key to success."
    ];
    return quotes[Math.floor(Math.random() * quotes.length)];
}

function toFancyUppercase(text) {
    const fonts = {
        'A': '𝐀', 'B': '𝐁', 'C': '𝐂', 'D': '𝐃', 'E': '𝐄', 'F': '𝐅', 'G': '𝐆', 'H': '𝐇', 'I': '𝐈', 'J': '𝐉', 'K': '𝐊', 'L': '𝐋', 'M': '𝐌',
        'N': '𝐍', 'O': '𝐎', 'P': '𝐏', 'Q': '𝐐', 'R': '𝐑', 'S': '𝐒', 'T': '𝐓', 'U': '𝐔', 'V': '𝐕', 'W': '𝐖', 'X': '𝐗', 'Y': '𝐘', 'Z': '𝐙'
    };
    return text.split('').map(char => fonts[char] || char).join('');
}

function toFancyLowercase(text) {
    const fonts = {
        "a": "ᴀ", "b": "ʙ", "c": "ᴄ", "d": "ᴅ", "e": "ᴇ", "f": "ꜰ", "g": "ɢ", "h": "ʜ", "i": "ɪ", "j": "ᴊ", "k": "ᴋ", "l": "ʟ", "m": "ᴍ", 
        "n": "ɴ", "o": "ᴏ", "p": "ᴘ", "q": "ϙ", "r": "ʀ", "s": "ꜱ", "t": "ᴛ", "u": "ᴜ", "v": "ᴠ", "w": "ᴡ", "x": "x", "y": "ʏ", "z": "ᴢ"
    };
    return text.split('').map(char => fonts[char.toLowerCase()] || fonts[char] || char).join('');
}

// ========== MENU STYLE (single style) ==========
const menuStyle = {
    render({ botName, prefix, totalCommands, version, categories, pushName }) {
        const greeting = getGreeting();
        const currentTime = getCurrentTime();
        const currentDate = getCurrentDate();
        const randomQuote = getRandomQuote();
        
        let menuText = `*╰►${greeting}, ${pushName || 'User'}!*\n\n`;
        menuText += `✨ *"${randomQuote}"* ✨\n\n`;
        
        // Bot info header
        menuText += `╭━━━  ⟮  ${botName} ⟯━━━━━━┈⊷\n`;
        menuText += `┃✵╭──────────────\n`;
        menuText += `┃✵│ ᴄᴏᴍᴍᴀɴᴅᴇʀ: ${pushName}\n`;
        menuText += `┃✵│ ᴛᴏᴛᴀʟ ᴘʟᴜɢɪɴs: ${totalCommands}\n`;
        menuText += `┃✵│ ᴛɪᴍᴇ: ${currentTime}\n`;
        menuText += `┃✵│ ᴅᴀᴛᴇ: ${currentDate}\n`;
        menuText += `┃✵│ ᴘʀᴇғɪx: ${prefix}\n`;
        menuText += '┃✵│ ʟɪʙʀᴀʀʏ: Baileys\n';
        menuText += `┃✵│ ᴠᴇʀsɪᴏɴ: ${version}\n`;
        menuText += '┃✵╰──────────────\n';
        menuText += '╰━━━━━━━━━━━━━━━━━━┈⊷\n\n';
        
        menuText += '━━━━━━━━━━━━━━━━━━━━\n';
        menuText += '*┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃𒊹┃:*\n\n';
        
        let commandCounter = 1;
        const categoryEntries = categories instanceof Map ? [...categories.entries()] : Object.entries(categories);
        for (const [cat, cmds] of categoryEntries) {
            const fancyCat = toFancyUppercase(cat.toUpperCase());
            menuText += ` ╭─────「 ${fancyCat} 」───┈⊷ \n`;
            for (const cmd of cmds) {
                const fancyCmd = toFancyLowercase(cmd);
                menuText += ` ││◦➛  ${commandCounter}. ${fancyCmd}\n`;
                commandCounter++;
            }
            menuText += ' ╰──────────────┈⊷ \n';
        }
        
        menuText += '\n━━━━━━━━━━━━━━━━━━━━\n';
        menuText += '_*“Code is poetry, and this bot is your muse.”*_\n';
        menuText += `💡 *Tip:* Use ${prefix}help <command> for details.`;
        
        return menuText;
    }
};

export default {
    command: 'menu',
    aliases: ['help', 'commands'],
    category: 'general',
    description: 'Show all commands',
    usage: '.menu [command]',
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const prefix = config.prefixes[0];
        const imagePath = path.join(process.cwd(), 'assets/thumb.png');
        
        // If a command name is provided, show detailed info
        if (args.length) {
            const searchTerm = args[0].toLowerCase();
            let cmd = commandHandler.commands.get(searchTerm);
            if (!cmd && commandHandler.aliases.has(searchTerm)) {
                const mainCommand = commandHandler.aliases.get(searchTerm);
                cmd = commandHandler.commands.get(mainCommand);
            }
            
            if (!cmd) {
                return sock.sendMessage(chatId, {
                    text: `❌ Command "${args[0]}" not found.\n\nUse ${prefix}menu to see all commands.`,
                    ...channelInfo
                }, { quoted: message });
            }
            
            const text = `╭━━━━━━━━━━━━━━⬣
┃ 📌 *COMMAND INFO*
┃
┃ ⚡ *Command:* ${prefix}${cmd.command}
┃ 📝 *Desc:* ${cmd.description || 'No description'}
┃ 📖 *Usage:* ${cmd.usage || `${prefix}${cmd.command}`}
┃ 🏷️ *Category:* ${cmd.category || 'misc'}
┃ 🔖 *Aliases:* ${cmd.aliases?.length ? cmd.aliases.map((a) => prefix + a).join(', ') : 'None'}
┃
╰━━━━━━━━━━━━━━⬣`;
            
            if (fs.existsSync(imagePath)) {
                return sock.sendMessage(chatId, {
                    image: { url: imagePath },
                    caption: text,
                    ...channelInfo
                }, { quoted: message });
            }
            return sock.sendMessage(chatId, { text, ...channelInfo }, { quoted: message });
        }
        
        // Main menu rendering
        const menuText = menuStyle.render({
            botName: config.botName,
            prefix: config.prefixes.join(', '),
            totalCommands: commandHandler.commands.size,
            version: config.version || "6.0.0",
            categories: commandHandler.categories,
            pushName: message.pushName || 'User'
        });
        
        if (fs.existsSync(imagePath)) {
            await sock.sendMessage(chatId, {
                image: { url: imagePath },
                caption: menuText,
                ...channelInfo
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, { text: menuText, ...channelInfo }, { quoted: message });
        }
    }
};