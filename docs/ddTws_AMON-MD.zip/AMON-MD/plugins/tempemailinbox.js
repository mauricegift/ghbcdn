/**
 * Inbox Command - Check temporary email inbox
 */

import axios from 'axios';
import config from '../config.js';

export default {
    name: 'inbox',
    aliases: ['checkinbox', 'tempmailinbox', 'inboxcheck'],
    category: 'general',
    description: 'Check temporary email inbox',
    usage: '.inbox <email>',
    
    async handler(sock, message, args, context) {
        try {
            const { chatId, sendReply } = context;
            const email = args[0];
            
            if (!email) {
                return sendReply(sock, message, `❌ Please provide the temporary email.\n\n📌 Usage: ${config.prefixes[0]}inbox example@tempmail.com\n\n💡 Use .tempmail to generate one.`);
            }
            
            await sendReply(sock, message, '⏳ Checking inbox...');
            
            const apiUrl = `https://api.giftedtech.co.ke/api/tempgen/v2/inbox?apikey=gifted&email=${encodeURIComponent(email)}`;
            const response = await axios.get(apiUrl);
            
            if (!response.data.success) {
                return sendReply(sock, message, '❌ No messages found in inbox.');
            }
            
            const messages = response.data.result;
            
            if (!messages || messages.length === 0) {
                return sendReply(sock, message, `📭 Inbox is empty for ${email}`);
            }
            
            let responseText = `📬 INBOX FOR ${email}\n\n`;
            let messageCount = 0;
            
            for (let i = 0; i < Math.min(messages.length, 10); i++) {
                const msg = messages[i];
                responseText += `📧 *From:* ${msg.from}\n`;
                responseText += `📝 *Subject:* ${msg.subject}\n`;
                responseText += `📅 *Date:* ${msg.date}\n\n`;
                messageCount++;
            }
            
            if (messages.length > 10) {
                responseText += `📌 *Showing ${messageCount} of ${messages.length} messages*\n`;
            }
            
            responseText += `\n✨ POWERED BY ${config.botName?.toUpperCase() || 'AMON-MD'}`;
            
            await sendReply(sock, message, responseText);
            
        } catch (error) {
            console.error('[AMON-MD] Inbox error:', error);
            const { sendReply } = context;
            sendReply(sock, message, '❌ Error checking inbox. Please try again later.');
        }
    }
};